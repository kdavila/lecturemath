import sys

sys.path.extend(['../'])
from graph import tools


class Graph:
    num_node = 18
    inward_ori_index = [(1, 0),
                        (2, 1), (3, 2), (4, 3),
                        (5, 1), (6, 5), (7, 6),
                        (8, 1), (9, 8), (10, 9),
                        (11, 1), (12, 11), (13, 12),
                        (14, 0), (15, 0), (16, 14), (17, 15)]

    self_link = [(i, i) for i in range(num_node)]
    inward = inward_ori_index
    outward = [(j, i) for (i, j) in inward]
    neighbor = inward + outward

    def __init__(self, labeling_mode='spatial'):
        self.A = self.get_adjacency_matrix(labeling_mode)
        self.num_node = Graph.num_node
        self.self_link = Graph.self_link
        self.inward = Graph.inward
        self.outward = Graph.outward
        self.neighbor = Graph.neighbor

    def get_adjacency_matrix(self, labeling_mode=None):
        if labeling_mode is None:
            return self.A
        if labeling_mode == 'spatial':
            A = tools.get_spatial_graph(Graph.num_node, Graph.self_link, Graph.inward, Graph.outward)
        else:
            raise ValueError()
        return A


class UpperBodyGraph:
    num_node = 14
    inward_ori_index = [(1, 0),
                        (2, 1), (3, 2), (4, 3),
                        (5, 1), (6, 5), (7, 6),
                        (8, 1), (9, 1),
                        (10, 0), (11, 0), (12, 10), (13, 11)]

    self_link = [(i, i) for i in range(num_node)]
    inward = inward_ori_index
    outward = [(j, i) for (i, j) in inward]
    neighbor = inward + outward

    def __init__(self, labeling_mode='spatial'):
        self.A = self.get_adjacency_matrix(labeling_mode)
        self.num_node = UpperBodyGraph.num_node
        self.self_link = UpperBodyGraph.self_link
        self.inward = UpperBodyGraph.inward
        self.outward = UpperBodyGraph.outward
        self.neighbor = UpperBodyGraph.neighbor

    def get_adjacency_matrix(self, labeling_mode=None):
        if labeling_mode is None:
            return self.A
        if labeling_mode == 'spatial':
            A = tools.get_spatial_graph(UpperBodyGraph.num_node, UpperBodyGraph.self_link, UpperBodyGraph.inward,
                                        UpperBodyGraph.outward)
        else:
            raise ValueError()
        return A


class UpperRightGraph:
    num_node = 12
    inward_ori_index = [(1, 0),
                        (2, 1), (3, 2), (4, 3),
                        (5, 1),
                        (6, 1), (7, 1),
                        (8, 0), (9, 0), (10, 8), (11, 9)]

    self_link = [(i, i) for i in range(num_node)]
    inward = inward_ori_index
    outward = [(j, i) for (i, j) in inward]
    neighbor = inward + outward

    def __init__(self, labeling_mode='spatial'):
        self.A = self.get_adjacency_matrix(labeling_mode)
        self.num_node = UpperRightGraph.num_node
        self.self_link = UpperRightGraph.self_link
        self.inward = UpperRightGraph.inward
        self.outward = UpperRightGraph.outward
        self.neighbor = UpperRightGraph.neighbor

    def get_adjacency_matrix(self, labeling_mode=None):
        if labeling_mode is None:
            return self.A
        if labeling_mode == 'spatial':
            A = tools.get_spatial_graph(UpperRightGraph.num_node, UpperRightGraph.self_link, UpperRightGraph.inward,
                                        UpperRightGraph.outward)
        else:
            raise ValueError()
        return A

if __name__ == '__main__':
    import matplotlib.pyplot as plt
    import os

    # os.environ['DISPLAY'] = 'localhost:11.0'
    A = Graph('spatial').get_adjacency_matrix()
    for i in A:
        plt.imshow(i, cmap='gray')
        plt.show()
    print(A)
