import argparse
import pickle

import numpy as np
from tqdm import tqdm


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--label', required=True, help='file with test labels')
    parser.add_argument('--joint', required=True, help='file with soft-max weights of the joint AGCN')
    parser.add_argument('--bone', required=True, help='file with soft-max weights of the bone AGCN')
    parser.add_argument('--alpha', default=1, help='weighted summation')
    arg = parser.parse_args()

    print("\nJoint weights file name:")
    print(arg.joint)
    print("\nBone weights file name:")
    print(arg.bone)
    print("\nLabels file name:")
    print(arg.label)

    label = open(arg.label, 'rb')
    label = np.array(pickle.load(label))
    r1 = open(arg.joint, 'rb')
    r1 = list(pickle.load(r1).items())
    r2 = open(arg.bone, 'rb')
    r2 = list(pickle.load(r2).items())
    right_num = total_num = right_num_5 = 0

    for i in tqdm(range(len(label[0]))):
        _, l = label[:, i]
        _, r11 = r1[i]
        _, r22 = r2[i]

        r = r11 + r22 * arg.alpha

        rank_5 = r.argsort()[-5:]
        right_num_5 += int(int(l) in rank_5)

        r = np.argmax(r)
        right_num += int(r == int(l))

        total_num += 1

    acc = right_num / total_num
    acc5 = right_num_5 / total_num
    print(acc * 100.0, acc5 * 100.0)


if __name__ == "__main__":
    main()
