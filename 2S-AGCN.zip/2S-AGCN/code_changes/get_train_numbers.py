
import sys

def main():
    if len(sys.argv) < 2:
        print("Usage")
        print("\tpython {0:s} input_log".format(sys.argv[0]))
        return

    log_filename = sys.argv[1]

    with open(log_filename, "r") as in_file:
        all_lines = in_file.readlines()

    pos = 0
    current_epoch = None
    epoch_numbers = {}
    while pos < len(all_lines):
        line = all_lines[pos].strip().lower()
        if "training epoch" in line:
            current_epoch = int(line.split(":")[-1].strip())

            if current_epoch is not None:
                epoch_numbers[current_epoch] = {
                    "train loss": None,
                    "test acc": None
                }

        if "mean training loss" in line:     
            epoch_numbers[current_epoch]["train loss"] = float(line.split(":")[-1].strip()[:-1])

        if "top1" in line:
            epoch_numbers[current_epoch]["test acc"] = float(line.split(":")[-1].strip()[:-1])

        pos += 1

    all_epochs = []
    all_losses = []
    all_accs = []
    for epoch in sorted(list(epoch_numbers.keys())):
        all_epochs.append(epoch)
        all_losses.append(epoch_numbers[epoch]["train loss"])
        all_accs.append(epoch_numbers[epoch]["test acc"])
        
    print(log_filename)
    print("\t".join([str(val) for val in all_epochs]))
    print("\t".join([str(val) for val in all_losses]))
    print("\t".join([str(val) for val in all_accs]))
    

if __name__ == "__main__":
    main()
